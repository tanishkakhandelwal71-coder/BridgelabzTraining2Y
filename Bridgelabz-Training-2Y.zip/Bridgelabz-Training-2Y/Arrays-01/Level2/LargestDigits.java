package Level2;
import java.util.Scanner;
public class LargestDigits {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int number = sc.nextInt();
        int[] digits = new int[10];
        int index = 0;
        while (number != 0) {
            int digit = number % 10;
            digits[index] = digit;
            index++;
            number = number / 10;
        }
        int largest = 0;
        int secondLargest = 0;
        for (int i = 0; i < index; i++) {
            if (digits[i] > largest) {
                secondLargest = largest;
                largest = digits[i];
            } else if (digits[i] > secondLargest &&
                    digits[i] != largest) {
                secondLargest = digits[i];
            }
        }
        System.out.println("Largest digit = " + largest);
        System.out.println("Second largest digit = " + secondLargest);
        sc.close();
    }
}